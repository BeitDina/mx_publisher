# MX-Publisher Style

Style name: MXP
Based on style: prosilver for phpBB3 by phpBB Group
Original author: OryNider, using prosilver style as a base.
This is an green colours responsive style for phpBB and MXP.

phpBB Version: 3.2.x Style Version: 3.2.x

Style Download: https://github.com/orynider/mxp/releases 

License: [GNU General Public License v2](http://opensource.org/licenses/GPL-2.0) 

The phpBB Romanian Online Comunity 

The Mx-Publisher CMS Project   .
